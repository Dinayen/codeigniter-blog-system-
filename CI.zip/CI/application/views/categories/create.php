<div class="title">
    <?php echo $title ?>
</div>

<div class="error_message">
    <?php echo validation_errors() ?>
</div>

<?php echo form_open_multipart('categories/create') ?>

  <label for="name">Name:</label>
  <input type="name" class="form-control" name="name" placeholder="Enter Category Name">
 
  <button type="submit" class="read-more">ADD</button>
<?php echo form_close() ?>