<br><br>
<div class="row">
    <div class="card-header container"><h1><?php  echo $title ?></h1></div>

    <?php  foreach ($posts as $post) :?>
        <div class="col-md-5 col-sm-12">
            <?php
                $singular_image = $post->image;
                if($singular_image = underscore($singular_image)): ?>
                    <img  src="<?php echo site_url(); ?>assets/images/posts/<?php echo underscore($singular_image); ?>" style="max-width:400px;">
            
                <?php elseif($singular_image = singular($singular_image)): ?>
                    <img  src="<?php echo site_url(); ?>assets/images/posts/<?php echo singular($singular_image); ?>" style="max-width:400px">
            <?php endif; ?>
        </div>
   
    <div class="col-md-7 col-sm-12">
       <h3><?php  echo $post->title; ?>
            <small class="post_date">
                    Posted on  <?php echo $post->date_added;?> in
                <strong>
                    <?php echo $post->name?>
                </strong>
            </small>
       </h3>
       <div class="card-body responsive">
        <?php echo word_limiter($post->body,20);?>
       </div>
       <p class="lead">
                <a href="<?php echo site_url('posts/').$post->slug?>" class="read-more">Read More</a>
        </p><br>
        <hr>
    </div>
  
    <?php  endforeach ;?>
</div>

    <div class="pagination-links  pagination-lg" >
        <?php echo $this->pagination->create_links(); ?>
    </div>