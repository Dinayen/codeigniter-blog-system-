<?php

  
            $singular_image = $post->image;
            if($singular_image = underscore($singular_image)): ?>
                <br><img  src="<?php echo site_url(); ?>assets/images/posts/<?php echo underscore($singular_image); ?>" class="single-images">
          
            <?php elseif($singular_image = singular($singular_image)): ?>
                <br><img  src="<?php echo site_url(); ?>assets/images/posts/<?php echo singular($singular_image); ?>" class="single-images">
           <?php endif; ?>
            <h3>
                <?php  echo $post->title; ?>
                <small class="post_date">
                    Posted on  <?php echo $post->date_added;?>
                </small>
            </h3>
                    
           <p> <?php echo $post->body;?></p>
                    
          

       
        <div class="buttons">
            <?php if($this->session->userdata("user_id") ==$post->user_id): ?>
                <p class="align-center"> 
                        <a href="<?php echo base_url()?>/posts/delete/<?php echo $post->id?>" class="read-more">Delete</a>
                        <a href="<?php echo base_url()?>/posts/edit/<?php echo $post->slug?>" class="read-more pull-left">Edit</a>
                </p>
                    
            <?php endif ?>
           
        </div>

        <hr>
        <h3>Comments</h3>
        <?php if($comments): ?>
            <?php  foreach ($comments as $comment): ?>
                <div class="card-body">
                    <h6><?php echo $comment->body?> by <strong><?php echo $comment->name?></strong> 
                        on <span><?php echo $comment->date_added?></span>
                    </h6><br>

                        
                    <!-- ++++++++++++++++++++++++++++++++Getting Replies+++++++++++++++++++++++++++++ -->
                      <div class="container">
                            <?php foreach ($reply as $replies ) : ?>
                                <h6><strong><?php echo $replies->names ?></strong> replied to your comment</h6>
                                <p class="text-success"><?php echo $replies->reply ?></p>
                        
                            <?php endforeach;?>
                      </div>

                    <!-- +++++++++++++++++++++++++++++++++++++SECTION ADD REPLY++++++++++++++++++++++++++++++++++++++++++++++++++++++ -->
                 <button class="read-more" data-toggle="modal" data-target="#myModal">Reply</button>                    
                        <div class="container">
                        <div class="modal" id="myModal">
                            <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h4 class="modal-title">Add Reply</h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <div class="error_message">
                                        <?php echo validation_errors() ?>
                                    </div>
                                        <?php echo form_open("reply/add_reply/".$comment->comments_id."/".$post->id) ?>

                                            <div class="form-group">
                                                <input type="text" name="name" placeholder="Your Name" class="form-control" required autocomplete>
                                            </div>
                                            <div class="form-group">
                                                <input type="email" name="email" placeholder="Enter Email" class="form-control" required>
                                            </div>
                                            <div class="form-group">
                                               <label for="">Reply Message</label><br>
                                               <textarea name="body" id="" cols="30" rows="5" class="form-control" required></textarea>
                                            </div>
                                            <div class="form-group">
                                                <input type="hidden" name="comment_id" value="<?php echo $comment->comments_id?>">
                                                <input type="hidden" name="slug" value="<?php echo $post->slug?>">
                                            </div>

                                            <div class="form-group">
                                                <button class="read-more">Submit</button>
                                                <button type="button" class="read-more" data-dismiss="modal">Close</button>
                                            </div>
                                           
                                        <?php echo form_close() ?>
                                </div>
                            </div>
                            </div>
                        </div>
                        
                        </div>

                    
            </div>
            <?php endforeach;?>
        <?php else:
            echo "No Comments for this post";    
        ?>

        <?php endif; ?>

        <hr>
        <h3>Add Comments</h3>
        <div class="error_message">
            <?php echo validation_errors() ?>
        </div>
        <?php echo form_open('comments/create/'.$post->id) ?>
           
                    <div class="form-group">
                        <label for="">Name</label>
                        <input type="text" name="name" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="email" name="email" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="">Body</label><br>
                        <textarea name="body" id="" cols="30" rows="5" class="form-control"></textarea>
                    </div>
                    <input type="hidden" name="slug" value="<?php echo $post->slug?>">
                    <div class="form-group">
                        <button class="read-more btn-block">Comment</button>
                    </div>
                
        <?php echo form_close() ?>
