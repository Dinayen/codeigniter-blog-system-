<div class="card-header">
    <?php echo $title ?>
</div>

<p class="error_message lead"><?php echo validation_errors() ?></p>

<?php echo form_open_multipart('posts/add_posts') ?>
    <div class="form-group">
        <label for="title">Title:</label>
        <input type="text" class="form-control"  name="title">
    </div>

   

    <div class="form-group">
      <label for="body">Body: </label>
      <textarea id="decription" name="body" class="myTextarea" rows="1" cols="3" class="form-control"> </textarea>
    </div>

   
    <div class="form-group">
        <label for="">Category:</label>
        <select name="category_id" id="" class="form-control">
            <?php foreach ($cat as $catgories):?>
            <option value="<?php  echo $catgories->cat_id; ?>"><?php  echo $catgories->name; ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label for="title">Upload Image:</label>
        <input type="file" class="form-control"  name="userfile" size="20">
    </div>
   

    <button type="submit" class="read-more">Submit</button>

<?php echo form_close() ?>

