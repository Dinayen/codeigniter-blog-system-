<?php

class Posts extends CI_Controller{
    public function index($offset =0){
       
        // pagination Config
        $config['base_url'] = base_url().'posts/index/';
        $config['total_rows'] = $this->db->count_all("posts");
        $config['per_page'] = 6;
        $config['uri_segment'] = 3;
        $config['attributes'] = array('class' => 'pagination-links');

        $this->pagination->initialize($config);

        $data['posts'] = $this->post_model->get_posts(FALSE,$config['per_page'],$offset);
        
        $data['title'] = "Latest Posts";
        $data['cat'] = $this->post_model->get_categories();
        

        $this->load->view('templates/header');
        $this->load->view('posts/index',$data);
         $this->load->view('templates/footer');
        
    }

    public function view_posts($slug = NULL)
    {
        $data['post'] =  $this->post_model->get_posts($slug);
        $post_id = $data['post']->id;
        
        $data["comments"] = $this->Comments_model->get_comments($post_id);
        
        $data["reply"] = $this->Reply_model->get_replies($post_id);
        
        if(empty($data['post']))
        {
            show_404();
        }
     
        $data['title'] = array('post','title');
      
        $this->load->view('templates/header');
        $this->load->view('posts/view_posts',$data);
        $this->load->view('templates/footer');
        
    }

   

    public function add_posts(){

        // Check if user has Login
        if(!$this->session->userdata('logged_in')) 
        {
            redirect('users/login');
        }
        $data['title'] = "Create Post";
        $data['cat'] = $this->post_model->get_categories();
        
        $this->form_validation->set_rules('title', 'Title', 'required');
        $this->form_validation->set_rules('body', 'Body', 'required');
        $this->form_validation->set_rules('category_id', 'Category Id', 'required');

        if($this->form_validation->run() == FALSE)
        {
            $this->load->view('templates/header');
            $this->load->view('posts/add_posts',$data);
            $this->load->view('templates/footer');
        }else{

            // Code for uploading Images
            $config['upload_path'] = './assets/images/posts';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size']     = '2048';
            $config['max_width'] = '1024';
            $config['max_height'] = '768';

            $this->load->library('upload', $config);
            if (! $this->upload->do_upload())
            {
                    $errors = array('error' => $this->upload->display_errors());
                    $this->load->view('posts/add_posts', $errors);
                    
            }
            else
            {
                   
                    $data = array('upload_data' => $this->upload->data());                   
            }
           
            $this->post_model->add();
            $this->session->set_flashdata('post_created', 'Your post has been Added');
            redirect('posts');
           
        }
    }

    public function delete($id)
    {
        // Check if user has Login
        if(!$this->session->userdata('logged_in')) 
        {
            redirect('users/login');
        }
        $this->post_model->delete_post($id);
        $this->session->set_flashdata('post_deleted', 'Your post has been Deleted');
        redirect('posts');
    }

    function edit($slug)
    {
        // Check if user has Login
        if(!$this->session->userdata('logged_in')) 
        {
            redirect('users/login');
        }
        $data['title'] = "Updating Post";
        $data['post'] =  $this->post_model->get_posts($slug);

        if($this->session->userdata("user_id") != $this->post_model->get_posts($slug)->user_id)
        {
            redirect("posts");
        }
        $data['cat'] = $this->post_model->get_categories();
        

        if(empty($data['post']))
        {
            show_404();
        }
        
        $this->form_validation->set_rules('title', 'Title', 'required');
       
        $data['title'] = "Update Post";
      
        $this->load->view('templates/header');
        $this->load->view('posts/edit',$data);
        $this->load->view('templates/footer');
        
    }
    

    function update()
    {
        // Check if user has Login
        if(!$this->session->userdata('logged_in')) 
        {
            redirect('users/login');
        }
        $this->post_model->edit_post();
        $this->session->set_flashdata('post_updated', 'Your post has been Updated');
        redirect('posts');
    }
}
?>

