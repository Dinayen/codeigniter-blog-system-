</div>
        <footer>
            <div class="top-footer">
            <div class="row">
                <div class="col-md-4 col-sm-12">
                            <ul>
                                <li class="pages">Pages</li>
                                
                                <li><a href="<?php echo base_url('/')?>" class="active">Home</a></li>
                                <li> <a href="<?php echo base_url()?>about">About Us</a></li>
                                <li><a href="<?php echo base_url('/posts')?>">Blog</a></li>
                                <li><a href="<?php echo base_url('/categories')?>">Categories</a></li>
                               
                                <?php if(!$this->session->userdata('logged_in')) : ?>
                                <li><a href="<?php echo base_url('/users/login')?>">Login</a></li>
                                <li><a  href="<?php echo base_url('/users/signup')?>">Signup</a></li>
                                <?php endif; ?>
                                <?php if($this->session->userdata('logged_in')): ?>
                                <li><a href="<?php echo base_url('/posts/add_posts')?>">Add Post</a></li>
                                <li><a href="<?php echo base_url('/categories/create')?>">Create Category</a></li>
                                <li><a href="<?php echo base_url('/users/logout')?>">Logout</a></li>
                                <?php endif; ?>    
               
                            </ul>
                </div>
                <div class="col-md-4 col-sm-12">
                    <ul>
                        <li class="pages">Support</li>
                        <li><span>&raquo</span><a href="#contact.php">Contact Us</a></li>
                    </ul>
                </div>

                <div class="col-md-4 col-sm-12">
                   <h5>We reply to all questions within</h5>
                   <h1 class="footer-24h">24h</h1>
                   <p> <span class="text-muted">We offer support for our customers</span><br>
                    Mon - Fri 8:00am - 6:00pm (GMT +1)</p>
                </div>
            </div>
            </div>
            <div class="bottom-footer">
                <p>Copyright. All rights reserved.</p>
            </div>
        </footer>

</body>
</html>