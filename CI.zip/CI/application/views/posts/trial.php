<form name="paypalFrm" id="paypalFrm" action="https://www.paypal.com/cgi-bin/webscr" method="post">
    <input type="hidden" name="cmd" value="_ext-enter">
    <input type="hidden" name="redirect_cmd" value="_xclick-subscriptions">
    <input type="hidden" name="return" value="<?php echo $return_url;?>">
    <input type="hidden" name="cancel_return" value="<?php echo $cancel_return;?>">
    <input type="hidden" name="notify_url" value="<?php echo $notify_url;?>">
    <input type="hidden" name="custom" value="<?php echo $custom.",".$custom2;?>">
    <input type="hidden" name="business" value="<?php echo $business_id;?>">
    <input type="hidden" name="item_name" value="<?php echo $item_name;?>">
    <input type="hidden" name="item_number" value="1">
    <input type="hidden" name="no_note" value="1">
    <input type="hidden" name="currency_code" value="USD">
    <input type="hidden" name="a3" value="<?php echo $plan_amount;?>">  
    <input type="hidden" name="p3" value="1">  
    <input type="hidden" name="t3" value="M">   
    <input type="hidden" name="src" value="1">
    <input type="hidden" name="sra" value="1">
    <input type="hidden" name="srt" value="12">
    <input type="hidden" name="first_name" value="<?php echo $txtname;?>">
    <input type="hidden" name="lc" value="<?php echo $merchant_country;?>">
    <input type="hidden" name="email" value="<?php echo $txtemail;?>">
</form>





$req = 'cmd=_notify-validate';
foreach ($_POST as $key => $value) { $_POST[$key] = mysql_real_escape_string($value); }         

foreach ($_POST as $key => $value) {
    $value = urlencode(stripslashes($value));
    $req .= "&$key=$value";
}

$header = ''; 
$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
$fp = fsockopen('www.sandbox.paypal.com', 80, $errno, $errstr, 30);

// assign posted variables to local variables

$content['payment_status']      = $this->input->post('payment_status');
$content['payment_amount']      = $this->input->post('mc_gross');
$content['payment_currency']    = $this->input->post('mc_currency');
$content['txn_id']              = $this->input->post('txn_id');
$content['receiver_email']      = $this->input->post('receiver_email');
$content['payer_email']         = $this->input->post('payer_email');    
$custom                         = explode(",",$this->input->post('custom'));
$content['payment_id']          = $custom[0];
$content['type']                = $custom[1];
$content['txn_type']            = $this->input->post('txn_type');        
$content['paydate']             = date('Y-m-d H:i:s');


if (!$fp)
{
    // HTTP ERROR
}
else
{

    fputs ($fp, $header . $req);
    if (!feof($fp))
    {
        $res = fgets ($fp, 1024);

        if(strcasecmp($content['txn_type'], "subscr_payment") == 0)
        {
            //Action            
        }
        else if(strcasecmp($content['payment_status'], "Completed") == 0)
        {
            //Action            
        }
        else if(strcasecmp($content['txn_type'], "subscr_cancel") == 0)
        {
           //Action            
        }
    }
    fclose ($fp);
}