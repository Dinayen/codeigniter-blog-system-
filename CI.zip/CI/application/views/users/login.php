
        <div class="error_message">
            <?php echo validation_errors() ?>
        </div>

            <?php echo form_open("users/login") ?>
                <div class="row">
                        <div class="col-md-4 offset-md-4">
                            <h1 class="text-center"><?php echo $title ?></h1>
                            <div class="form-group">
                                <input type="text" class="form-control" name="user" placeholder="Enter Username" required autofocus>
                            </div>

                            <div class="form-group">
                                <input type="password" class="form-control" name="password"  placeholder="Enter Password" required autofocus>
                            </div>
                            <button type="submit" class="read-more btn-block">LOGIN</button>
        
                        
                        </div>
                </div>
            <?php echo form_close() ?>

</body>
</html>