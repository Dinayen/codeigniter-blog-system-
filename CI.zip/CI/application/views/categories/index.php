<?php echo $title ?>
<ul class="list-group">
    
    <?php foreach ($categories as $category): ?>
        <li class="list-group-item">
           <a href="<?php echo site_url('/categories/posts/'.$category->cat_id)?>">
           <?php echo $category->name ?>
           </a>
           <?php if($this->session->userdata("user_id") == $category->user_id): ?>
               <form  class="cat-delete" action="categories/delete/<?php echo $category->cat_id ?>" method="post">
                    <input type="submit" value="[x]" class="btn-link text-danger">
               </form>
            <?php endif; ?>
        </li>
    <?php endforeach; ?>

</ul>