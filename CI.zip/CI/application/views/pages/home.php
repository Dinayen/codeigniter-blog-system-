<div class="container">
   
        <!-- echo $count -->
        
        <!--==============================================Carousel Begins================================================================ -->
   
        <div id="demo" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->
            <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
            </ul>

            <!-- The slideshow -->
            <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo base_url()?>/assets/img/pic.jpg" alt="Slider One" width="1200" height="500">
            </div>
            <div class="carousel-item">
                <img src="<?php echo base_url()?>/assets/img/discipline.jpg" alt="Slider Two" width="1200" height="500">
            </div>
            <div class="carousel-item">
                <img src="<?php echo base_url()?>/assets/img/pic01.jpg" alt="Slider Three" width="1200" height="500">
            </div>
            </div>

            <!-- Left and right controls -->
            <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            </a>
        </div>

        <!-- ================================================Carousel Ends Here================================================================ -->


        <!-- ================================================Our Services Begins================================================================ -->
        <br><br>
        <div class="section-title">
            <h3>Our Services</h3>
        </div>
        <div class="row box">
            
            <div class="col-md-4 col-sm-12 box1">
                <div class="card">
                    <div class="card-body">
                        <img src="<?php echo base_url()?>/assets/img/pic04.jpg" alt="" style="width:300px;height:250px;">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate inventore temporibus dolore tenetur obcaecati sapiente
                            porro assumenda. Laudantium, assumenda quisquam.
                    </div>
                    <button class="read-more">Read More  &raquo</button>
                </div>
            </div>
            <div class="col-md-4 col-sm-12 box2">
                <div class="card">
                    <div class="card-body">
                        <img src="<?php echo base_url()?>/assets/img/pic03.jpg" alt="" style="width:300px;height:250px;">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate inventore temporibus dolore tenetur obcaecati sapiente
                            porro assumenda. Laudantium, assumenda quisquam.
                    </div>
                    <button class="read-more">Read More  &raquo</button>
                </div>
            </div>
            <div class="col-md-4 col-sm-12 box3">
                <div class="card">
                    <div class="card-body">
                        <img src="<?php echo base_url()?>/assets/img/background2.jpg" alt="" style="width:300px;height:250px;">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate inventore temporibus dolore tenetur obcaecati sapiente
                            porro assumenda. Laudantium, assumenda quisquam.
                    </div>
                    <button class="read-more">Read More  &raquo</button>
                </div>
            </div>
        </div>

        <!-- ================================================Our Services Ends================================================================ -->

    
        <!-- ================================================Section Testimonials================================================================ -->

            <div class="section-title">
                <h3>Testimonials</h3>
            </div>
           
        <div id="demo" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->
            <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
            </ul>

            <!-- The slideshow -->
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <p class="description">
                        Bootstrap 4 supports the latest, stable releases of all major browsers and platforms. However, Internet Explorer 9 and down is not supported.
                        Bootstrap 4 supports the latest, stable releases of all major browsers and platforms. However, Internet Explorer 9 and down is not supported.
                    </p>
                    <div class="content">
                        <h3 class="title">Lawrence</h3>
                        <center><img src="<?php echo base_url()?>/assets/img/1.jpg" alt="" class="rounded-circle img-thumbnail " style="max-width:80px"></center>
                        <span class="post">Web Developer</span>
                    </div>
                </div>

                <div class="carousel-item">
                    <p class="description">
                        Bootstrap 4 supports the latest, stable releases of all major browsers and platforms. However, Internet Explorer 9 and down is not supported.
                        Bootstrap 4 supports the latest, stable releases of all major browsers and platforms. However, Internet Explorer 9 and down is not supported.
                        
                    </p>
                    <div class="content">
                        <h3 class="title">Lawrence</h3>
                        <center><img src="<?php echo base_url()?>/assets/img/1.jpg" alt="" class="rounded-circle img-thumbnail " style="max-width:80px"></center>
                        <span class="post">Web Developer</span>
                    </div>
                </div>

                <div class="carousel-item">
                    <p class="description">
                        Bootstrap 4 supports the latest, stable releases of all major browsers and platforms. However, Internet Explorer 9 and down is not supported.
                        Bootstrap 4 supports the latest, stable releases of all major browsers and platforms. However, Internet Explorer 9 and down is not supported.
                    </p>
                    <div class="content">
                        <h3 class="title">Lawrence</h3>
                        <center><img src="<?php echo base_url()?>/assets/img/1.jpg" alt="" class="rounded-circle img-thumbnail " style="max-width:80px"></center>
                        <span class="post">Web Developer</span>
                    </div>
                </div>

            </div>

            <!-- Left and right controls -->
            <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            </a>
            </div>


        <!-- ================================================Testimonial Ends================================================================ -->


        <!-- ================================================Contact Us Starts================================================================ -->
            <div class="section-title">
                <h3>Contact Us</h3>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-12 our-contacts">
                    <div class="contact-head">
                        <i class="fa fa-phone"></i>
                        <h5>Contact Us For more info.</h5>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. In, tempore?</p>
                    </div>
                    <ul class="list-group">
                        <li class="list-group-item">
                            <a href="http://www.facebook.com/Dinayen"><i class="fa fa-facebook"></i></a>
                            <a href="http://www.instagram.com/"><i class="fa fa-instagram"></i></a>
                            <a href="http://www.github.com/"><i class="fa fa-github"></i></a>
                        </li>
                        <li class="list-group-item">  <i class="fa fa-phone"></i> +670984322</li>
                        <li class="list-group-item">dinayenstephanie047@gmail.com</li>
                        <li class="list-group-item">Western Indies</li>
                    </ul> 
                </div>
                <div class="col-md-6 col-sm-12 your-contact">
                    <div class="error_message">
                    <?php echo validation_errors() ?>
                    </div>
                    <div class="contact-title">
                        <h5>Please fill out this form</h5>
                        <?php echo form_open('contact/add_contacts')?>
                            <div class="form-group">
                                <input type="name" name="name" placeholder="Name"  class="form-control" required >
                           </div>
                           <div class="form-group">
                                <input type="email" name="email" placeholder="Email"  class="form-control" required >
                           </div>
                           <div class="form-group">
                                <input type="number" name="phone" placeholder="Phone"  class="form-control" required >
                           </div>
                           <div class="form-group">
                                <input type="text" name="message" placeholder="Enter Mesage"  class="form-control" required >
                           </div>
                           <div class="form-group">
                                <input type="submit" class="read-more btn-block" value="Submit">
                           </div>
                        <?php echo form_close() ?>
                    </div>
                </div>
            </div>

        <!-- ================================================Contact Us Ends================================================================ -->

</div>


