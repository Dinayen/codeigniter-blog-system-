<?php

class Post_model extends CI_Model{
    public function __construct(){
        $this->load->database();
    }
    public function get_posts($slug = FALSE,$limit = FALSE,$offset=FALSE)
    {
        if($limit)
        {
            $this->db->limit($limit,$offset);
        }
        if($slug === FALSE)
        {
            $this->db->order_by('posts.id', 'DESC');
            $this->db->join('categories','categories.cat_id = posts.category_id');
            $query = $this->db->get('posts');
            return $query->result();
        }
        
        $query = $this->db->get_where('posts',array('slug' => $slug));
        return $query->row();
    }
    
    public function get_post()
    {
            $this->db->order_by('id', 'DESC');
            $query = $this->db->get('posts');
            return $query->row_array();
    }

    public function add()
    {
        
        $slug = url_title($this->input->post('title'));
        $info = array(
            "category_id" =>  $this->input->post('category_id'),
            "user_id" => $this->session->userdata("user_id"),
            "title" =>  $this->input->post('title'),
            "slug" => $slug,
            "body" =>   $this->input->post('body'),
            'image' => $_FILES['userfile']['name']
        );

        $this->db->insert('posts',$info);
      
    }

    public function get_categories()
    {
        $this->db->order_by('name','DESC');
        $query = $this->db->get('categories');

        return $query->result();
       
    }

    public function delete_post($id)
    {
        $this->db->where('id',$id);
        $this->db->delete('posts');
    }

    public function edit_post()
    {
        $id = $this->input->post('id');
        $this->db->where('id',$id);
        $slug = url_title($this->input->post('title'));

        
        $this->db->update('posts',array(
            "category_id" =>  $this->input->post('category_id'),
            "title" =>  $this->input->post('title'),
            "slug" => $slug,
            "body" =>   $this->input->post('body'),
            "image" => $_FILES['userfile']['name']
        ));
    }

    public function get_post_by_category($id)
    {
        $this->db->order_by('posts.id', 'DESC');
        $this->db->join('categories','categories.cat_id = posts.category_id');
        $query = $this->db->get_where('posts',array("category_id" => $id));
        return $query->result();
    }
}
?>


