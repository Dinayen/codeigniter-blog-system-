<?php
defined('BASEPATH') OR exit('No direct script access allowed');

;
$route['users/login'] = 'users/login';
$route['users/signup'] = 'users/signup';

// $route['posts/delete/(:num)'] = 'posts/delete/$1';
$route['posts/index'] = 'posts/index';
$route['posts/update'] = 'posts/update';
$route['posts/add_posts'] = 'posts/add_posts';
$route['posts/(:any)'] = 'posts/view_posts/$1';
$route['posts'] = 'posts/index';

$route['default_controller'] = 'pages/view';


$route['categories'] = 'categories/index';
$route['categories/create'] = 'categories/create';
$route['categories/posts/(:any)'] = 'categories/posts/$1';


// Going directly to the page you have choosen on your URL
$route['(:any)'] = 'pages/view/$1';



$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

?>