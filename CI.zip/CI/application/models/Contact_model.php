<?php

class Contact_model extends CI_Model{

    public function __construct()
    {
        $this->load->database();
    }
    
    public function contact()
    {
        $data = array(
            "name" => $this->input->post("name"),
            "email" => $this->input->post("email"),
            "phone" => $this->input->post("phone"),
            "message" => $this->input->post("message")
        );

        $this->db->insert("contact", $data);
    }
}
?>