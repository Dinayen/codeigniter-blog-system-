<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Codeigniter Blog</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.scss')?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/font/css/all.min.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/font/css/fontawesome.min.css')?>"
    <script src="<?php echo base_url('assets/js/script.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/jquery-3.3.1.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/font/js/fontawesome.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/tinymce/js/tinymce/jquery.tinymce.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/tinymce/js/tinymce/tinymce.min.js') ?>"></script>
   
    <script type="text/javascript">
    tinymce.init({
    selector: '.myTextarea',
    theme: 'modern',
    branding:false,
    plugins: [
      'advlist autolink link image lists charmap print preview hr anchor pagebreak spellchecker',
      'searchreplace wordcount visualblocks visualchars code fullscreen insertdatetime media nonbreaking',
      'save table contextmenu directionality emoticons template paste textcolor'
    ],
    content_css: 'css/content.css',
    toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | print preview media fullpage | forecolor backcolor emoticons'
  });
  </script>
</head>
<body>

<div class="top-nav">
    <div class="email">
        <i class="fa fa-envelope"></i>stacys@gmail.com
    </div>
</div>
<div class="nav-content container-fluid">
  <div class="row">
    <div class="col-md-12 col-sm-12 logo">
        <p>LOGO</p>
    </div>
    
  </div>
</div>
<div class="topnav" id="myTopnav">
            <a href="<?php echo base_url('/')?>" class="active home">Home</a>
                <a href="<?php echo base_url()?>about">About Us</a>
                <a class="nav-link" href="<?php echo base_url('/posts')?>">Blog</a>
                <a class="nav-link" href="<?php echo base_url('/categories')?>">Categories</a>
                
                <div>
                    <?php if(!$this->session->userdata('logged_in')) : ?>
                        <a class="nav-link " href="<?php echo base_url('/users/login')?>">Login</a>
                        <a class="nav-link " href="<?php echo base_url('/users/signup')?>">Signup</a>
                    <?php endif; ?>
                    
                    <?php if($this->session->userdata('logged_in')): ?>
                        <a class="nav-link" href="<?php echo base_url('/posts/add_posts')?>">Add Post</a>
                        <a class="nav-link " href="<?php echo base_url('/categories/create')?>">Create Category</a>
                        <a class="nav-link " href="<?php echo base_url('/users/logout')?>">Logout</a>
                    <?php endif; ?>
                </div>
                <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()"><i class="fa fa-bars"></i></a>
        </div>
<div class="container">

<?php if($this->session->flashdata('user_registered')):?>
    <?php echo '<p class="alert alert-success">'.$this->session->flashdata('user_registered').'</p>'?>
<?php endif; ?>

<?php if($this->session->flashdata('category_created')):?>
    <?php echo '<p class="alert alert-success">'.$this->session->flashdata('category_created').'</p>'?>
<?php endif; ?>

<?php if($this->session->flashdata('post_updated')):?>
    <?php echo '<p class="alert alert-success">'.$this->session->flashdata('post_updated').'</p>'?>
<?php endif; ?>

<?php if($this->session->flashdata('post_created')):?>
    <?php echo '<p class="alert alert-success">'.$this->session->flashdata('post_created').'</p>'?>
<?php endif; ?>

<?php if($this->session->flashdata('post_deleted')):?>
    <?php echo '<p class="alert alert-success">'.$this->session->flashdata('post_deleted').'</p>'?>
<?php endif; ?>


<?php if($this->session->flashdata('user_logged')):?>
    <?php echo '<p class="alert alert-success">'.$this->session->flashdata('user_logged').'</p>'?>
<?php endif; ?>


<?php if($this->session->flashdata('login_failed')):?>
    <?php echo '<h4 class="alert alert-danger">'.$this->session->flashdata('login_failed').'</h4>'?>
<?php endif; ?>

<?php if($this->session->flashdata('user_logout')):?>
    <?php echo '<h4 class="alert alert-success">'.$this->session->flashdata('user_logout').'</h4>'?>
<?php endif; ?>

<?php if($this->session->flashdata('category_deleted')):?>
    <?php echo '<h4 class="alert alert-success">'.$this->session->flashdata('category_deleted').'</h4>'?>
<?php endif; ?>

<?php if($this->session->flashdata('contact_added')):?>
    <?php echo '<h4 class="alert alert-success">'.$this->session->flashdata('contact_added').'</h4>'?>
<?php endif; ?>



