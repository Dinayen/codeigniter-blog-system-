<?php

class Visitors_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }

    public function visitors($ip)
    {
        $sql = $this->db->get_where("visitors",array("ip_address" => $ip));
        if(!$sql)
        {
           return TRUE;
        }else
        {
        $result = $sql->num_rows;
        
        if($result < 1)
        {
            $this->db->insert("visitors",array(
                "ip_address" => $ip
            ));
        }
        }
       
    }
}
?>