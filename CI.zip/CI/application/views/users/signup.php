
    <div class="container">
        
        <div class="error_message">
            <?php echo validation_errors() ?>
        </div>

            <?php echo form_open('users/signup') ?>
            <div class="row">
                <div class="col-md-4 offset-md-4">
                    <h2 class="title text-center  p-2 "><?php echo $title ?></h2>

                    <div class="form-group">
                        <input type="text" class="form-control" name="name"  placeholder="Enter Name" required autofocus>
                    </div>

                    <div class="form-group">
                        <input type="text" class="form-control" name="zipcod"  placeholder="Enter zipcode" required autofocus>
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" name="email" placeholder="Email Address" required autofocus>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="user" placeholder="Enter Username" required autofocus>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="password" placeholder="Enter Password" required autofocus>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" name="password2" placeholder="Confirmed Password" required autofocus>
                    </div>

                    <button type="submit" class="read-more btn-block">REGISTER</button>

                </div>
            </div>
              
            <?php echo form_close() ?>
    </div>
</body>
</html>