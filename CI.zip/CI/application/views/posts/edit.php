<h2 class="text-center card-header"><?php echo $title ?></h2>

<p class="error_message lead"><?php echo validation_errors() ?></p>

<?php echo form_open('posts/update') ?>
    <input type="hidden" name="id" id="" value="<?php echo $post->id ?>">
    <div class="form-group">
        <label for="title">Title:</label>
        <input type="text" class="form-control"  name="title" value="<?php echo $post->title ?>">
    </div>

    <div class="form-group">
      <label for="body">Body: </label>
      <textarea id="decription" name="body" class="myTextarea" rows="1" cols="3" class="form-control"> <?php echo $post->body ?></textarea>
    </div>
   
    <div class="form-group">
        <label for="">Category:</label>
        <select name="category_id" id="" class="form-control">
            <?php foreach ($cat as $catgories):?>
            <option value="<?php  echo $catgories->cat_id; ?>"><?php  echo $catgories->name; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    
   
    <button type="submit" class="read-more">Update</button>

<?php echo form_close() ?>