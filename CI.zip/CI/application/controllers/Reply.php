<?php

class Reply extends CI_Controller{

    public function add_reply($id,$post_id)
    {

        $slug = $this->input->post("slug");
        $data['post'] =  $this->post_model->get_posts($slug);
        
        $this->form_validation->set_rules("name", "Name", "required|trim|min_length[5]");
        $this->form_validation->set_rules("email", "Email", "required|valid_email");
        $this->form_validation->set_rules("body", "Reply", "required|trim");
        
        
        if($this->form_validation->run()  == FALSE)
        {
            $this->load->view('templates/header');
            $this->load->view('posts/view_posts',$data);
            $this->load->view('templates/footer');
        }
        else
        {
            $this->Reply_model->reply($id,$post_id);
            redirect("posts/".$slug);
        }

       
    }


}

?>