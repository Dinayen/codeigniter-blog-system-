<?php

class Pages extends CI_Controller{
    public function view($page = 'home'){
        if(!file_exists(APPPATH.'views/pages/'. $page. '.php'))
        {
            show_404();
        }
        else if($page == "home")
        {

           
            $ip = $_SERVER['REMOTE_ADDR'];
            $data['count']= $this->db->count_all("visitors");
            $this->Visitors_model->visitors($ip);     

           
            $data['title'] = ucfirst($page);
            $this->load->view('templates/header');
            $this->load->view('pages/'.$page,$data);
            $this->load->view('templates/footer');

        }
        else if($page == "about")
        {
            $data['sidebar'] = "Category";
            $data['recent'] = "Recent Posts";

            $data['categories'] = $this->category_model->get_categories();

            $data["recentPosts"] = $this->post_model->get_post();

            $this->load->view('templates/header');
            $this->load->view('pages/about',$data);
            $this->load->view('templates/footer');
        }
        else{
            $data['title'] = ucfirst($page);
            $this->load->view('templates/header');
            $this->load->view('pages/'.$page,$data);
            $this->load->view('templates/footer');
        }
    }

}
?>