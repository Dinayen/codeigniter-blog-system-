<?php

class Reply_model extends CI_Model{

    public function __construct()
    {
        $this->load->database(); 
    }

    public function reply($id, $post_id)
    {

        $data = array(
            "comment_id" => $id,
            "post_id" => $post_id,
            "names" => $this->input->post("name"),
            "email" => $this->input->post("email"),
            "reply"  => $this->input->post("body")
        );

        return $this->db->insert("reply", $data);
    }

    public function get_replies($post_id)
    {
        $query = $this->db->get_where("reply", array(
            "post_id" => $post_id
        ));
        return $query->result();

    }
   
}
?>