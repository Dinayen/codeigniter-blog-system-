  
        <!--==============================================Carousel Begins================================================================ -->
   
        <div id="demo" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->
            <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
            </ul>

            <!-- The slideshow -->
            <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo base_url()?>/assets/img/pic.jpg" alt="Slider One" width="1200" height="500">
            </div>
            <div class="carousel-item">
                <img src="<?php echo base_url()?>/assets/img/discipline.jpg" alt="Slider Two" width="1200" height="500">
            </div>
            <div class="carousel-item">
                <img src="<?php echo base_url()?>/assets/img/pic01.jpg" alt="Slider Three" width="1200" height="500">
            </div>
            </div>

            <!-- Left and right controls -->
            <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            </a>
        </div>

        <!-- ================================================Carousel Ends Here================================================================ -->



        <!-- ================================================About Content Here================================================================ -->
            <div class="about-content">
                <div class="row">
                    <div class="col-md-8 col-sm-12">
                        <div class="about-title">OUR STORY</div>
                        <div class="row">
                            <div class="col-md-6 col-sm-12 our-story">
                                <img src="<?php echo base_url()?>/assets/img/2.jpg" alt="Slider One" width="100%" height="250">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Est, pariatur?</p>
                            </div>
                            <div class="col-md-6 col-sm-12 our-story">
                                <img src="<?php echo base_url()?>/assets/img/3.jpg" alt="Slider One" width="100%" height="250">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Est, pariatur?</p>
                            </div>
                        </div>
                        <div class="about-title">OUR TEAM</div>
                        <div class="row">
                            <div class="col-md-6 col-sm-12 our-team">
                                <img src="<?php echo base_url()?>/assets/img/pic04.jpg" alt="Slider One" width="100%" height="250">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Est, pariatur?</p>
                            </div>
                            <div class="col-md-6 col-sm-12 our-team">
                                <img src="<?php echo base_url()?>/assets/img/pic05.jpg" alt="Slider One" width="100%" height="250">
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Est, pariatur?</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="sidebar-content">
                        
                            <div class="sidebar-title">
                                <?php echo $sidebar?>
                            </div>
                            <?php foreach ($categories as $category): ?>
                                <ul class="list-group">
                                
                                        <li class="list-group-item">
                                        <a href="<?php echo site_url('/categories/posts/'.$category->cat_id)?>">
                                        <?php echo $category->name ?>
                                        </a>
                                        
                                        </li>
                                
                                </ul> 
                            <?php endforeach; ?>
                            <div class="sidebar-title">
                                <?php echo $recent; ?>
                            </div>
                            
                                <ul class="list-group">
                                
                                        <li class="list-group-item">
                                            <a href="<?php echo site_url('/posts/index')?>">
                                            <?php echo $recentPosts['title'] ?>
                                            </a>
                                            <?php echo word_limiter($recentPosts['body'],20) ?>
                                        </li>
                                
                                </ul> 
                            

                            <div class="sidebar-title"></div>
                        </div>
                    </div>
                </div>
            </div>
        <!-- ================================================About Content Ends================================================================ -->


