<?php

class Contact extends CI_Controller{

    public function add_contacts()
    {
        $this->form_validation->set_rules("name" , "Name", "required");
        $this->form_validation->set_rules("email" , "email", "required");
        $this->form_validation->set_rules("phone" , "Phone Number", "required");
        $this->form_validation->set_rules("message" , "Message", "required");
       
        if( $this->form_validation->run() ===  FALSE)
        {
            $this->load->view("templates/header");
            $this->load->view("home");
            $this->load->view("templates/footer");
        }
        else
        {
            $this->Contact_model->contact();
            $this->session->set_flashdata('contact_added', 'Your Contact Details have been added');
            redirect("home");
        }
    }
}
?>